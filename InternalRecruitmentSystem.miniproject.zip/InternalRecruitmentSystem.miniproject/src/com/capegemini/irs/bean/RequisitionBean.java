package com.capegemini.irs.bean;

public class RequisitionBean {
private String requisitionId;
private String rmId;
private String projectId;
private String startDate;
private String closingDate;
private String currentStatus;
private String vacancyName;
private String skill;
private String domain;
private CharSequence numberRequired;

public String getRequisitionId() {
	return requisitionId;
}

public void setRequisitionId(String requisitionId) {
	this.requisitionId = requisitionId;
}

public String getRmId() {
	return rmId;
}

public void setRmId(String rmId) {
	this.rmId = rmId;
}

public String getProjectId() {
	return projectId;
}

public void setProjectId(String projectId) {
	this.projectId = projectId;
}

public String getStartDate() {
	return startDate;
}

public void setStartDate(String startDate) {
	this.startDate = startDate;
}

public String getClosingDate() {
	return closingDate;
}

public void setClosingDate(String closingDate) {
	this.closingDate = closingDate;
}

public String getCurrentStatus() {
	return currentStatus;
}

public void setCurrentStatus(String currentStatus) {
	this.currentStatus = currentStatus;
}

public String getVacancyName() {
	return vacancyName;
}

public void setVacancyName(String vacancyName) {
	this.vacancyName = vacancyName;
}

public String getSkill() {
	return skill;
}

public void setSkill(String skill) {
	this.skill = skill;
}

public String getDomain() {
	return domain;
}

public void setDomain(String domain) {
	this.domain = domain;
}

public CharSequence getNumberRequired() {
	return numberRequired;
}

public void setNumberRequired(CharSequence vacancy) {
	this.numberRequired = vacancy;
}

public RequisitionBean() {
	super();
	// TODO Auto-generated constructor stub
}

public RequisitionBean(String requisitionId, String rmId, String projectId, String startDate, String closingDate,
		String currentStatus, String vacancyName, String skill, String domain, CharSequence numberRequired) {
	super();
	this.requisitionId = requisitionId;
	this.rmId = rmId;
	this.projectId = projectId;
	this.startDate = startDate;
	this.closingDate = closingDate;
	this.currentStatus = currentStatus;
	this.vacancyName = vacancyName;
	this.skill = skill;
	this.domain = domain;
	this.numberRequired = numberRequired;
}

public RequisitionBean(String rmId, String projectId, String closingDate, String currentStatus, String vacancyName,
		String skill, String domain, CharSequence numberRequired) {
	super();
	this.rmId = rmId;
	this.projectId = projectId;
	this.closingDate = closingDate;
	this.currentStatus = currentStatus;
	this.vacancyName = vacancyName;
	this.skill = skill;
	this.domain = domain;
	this.numberRequired = numberRequired;
}

public RequisitionBean(String rmId, String projectId, String vacancyName, String skill, String domain,
		CharSequence numberRequired) {
	super();
	this.rmId = rmId;
	this.projectId = projectId;
	this.vacancyName = vacancyName;
	this.skill = skill;
	this.domain = domain;
	this.numberRequired = numberRequired;
}

public RequisitionBean(String string, String string2, String string3, String string4, String string5, String string6,
		String string7, String string8, String string9, char c) {
	// TODO Auto-generated constructor stub
}

@Override
public String toString() {
	return "requisitionId=" + requisitionId + ", rmId=" + rmId + ", projectId=" + projectId
			+ ", startDate=" + startDate + ", closingDate=" + closingDate + ", currentStatus=" + currentStatus
			+ ", vacancyName=" + vacancyName + ", skill=" + skill + ", domain=" + domain + ", numberRequired="
			+ numberRequired + "";
}




}
