package com.capegemini.irs.bean;

public class ReqEmployee 
{
	private String reqId;
	private String employeeId;
	private String name;
	private String projectId;
	private String skill;
	private String domain;
	private int experience;
	
	public String getReqId() {
		return reqId;
	}
	
	public void setReqId(String reqId) {
		this.reqId = reqId;
	}
	
	public String getEmployeeId() {
		return employeeId;
	}
	
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getProjectId() {
		return projectId;
	}
	
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	
	public String getSkill() {
		return skill;
	}
	
	public void setSkill(String skill) {
		this.skill = skill;
	}
	
	public String getDomain() {
		return domain;
	}
	
	public void setDomain(String domain) {
		this.domain = domain;
	}
	
	public int getExperience() {
		return experience;
	}
	
	public void setExperience(int experience) {
		this.experience = experience;
	}
	
	public ReqEmployee() {
		super();		
	}
	
	public ReqEmployee(String reqId, String employeeId, String name, String projectId, String skill, String domain,
			int experience) {
		super();
		this.reqId = reqId;
		this.employeeId = employeeId;
		this.name = name;
		this.projectId = projectId;
		this.skill = skill;
		this.domain = domain;
		this.experience = experience;
	}
	
	@Override
	public String toString() {
		return "reqId=" + reqId + ", employeeId=" + employeeId + ", name=" + name + ", projectId="
				+ projectId + ", skill=" + skill + ", domain=" + domain + ", experience=" + experience + "";
	}
	
	
	
}
