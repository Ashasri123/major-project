package com.capegemini.irs.bean;

public class ProjectBean {
private String projectId;
private String projectName;
private String description;
private String startDate;
private String endDate;
private String rmId;
public String getProjectId() {
	return projectId;
}
public void setProjectId(String projectId) {
	this.projectId = projectId;
}
public String getProjectName() {
	return projectName;
}
public void setProjectName(String projectName) {
	this.projectName = projectName;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getStartDate() {
	return startDate;
}
public void setStartDate(String startDate) {
	this.startDate = startDate;
}
public String getEndDate() {
	return endDate;
}
public void setEndDate(String endDate) {
	this.endDate = endDate;
}
public String getRmId() {
	return rmId;
}
public void setRmId(String rmId) {
	this.rmId = rmId;
}
public ProjectBean() {
	super();
	// TODO Auto-generated constructor stub
}
public ProjectBean(String projectId, String projectName, String description, String startDate, String endDate,
		String rmId) {
	super();
	this.projectId = projectId;
	this.projectName = projectName;
	this.description = description;
	this.startDate = startDate;
	this.endDate = endDate;
	this.rmId = rmId;
}
@Override
public String toString() {
	return " projectId=" + projectId + ", projectName=" + projectName + ", description=" + description
			+ ", startDate=" + startDate + ", endDate=" + endDate + ", rmId=" + rmId + "";
}

}
