package com.capegemini.irs.test;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.capegemini.irs.bean.AdminBean;
import com.capegemini.irs.bean.EmployeeBean;
import com.capgemini.irs.dao.AdminDao;
import com.capgemini.irs.exception.InternalRecruitmentSystemException;
import com.capgemini.irs.util.DbUtility;

public class AdminTest 
{
	Connection conn=null;
	AdminBean admin=null;
	AdminDao adao=null;
	List userList=null;
	String user1=null;

@Before
public void init() throws IOException
{
	 conn=DbUtility.getConnect();
}
@Test
public void checkDbConnectivity()
{
	
	 Assert.assertNotNull(conn);
}

@After
public void destroy()
{
	 conn=null;
}
@Before
public void init1()
{
	 adao=new AdminDao();
	 admin=new AdminBean("admin","admin","ADMIN");
}
@Test
public void addUsers() throws IOException, InternalRecruitmentSystemException
{
	int returnId=adao.addUsers(admin);
	Assert.assertEquals(1, returnId);
}

@After
public void destroy1()
{
	 adao=null;
}
@Before
public void init2()
{
	 adao=new AdminDao();
	 admin=new AdminBean("admin","admin","ADMIN");
	
}
@Test
public void retriveAllUsers() throws IOException, InternalRecruitmentSystemException
{
	List<AdminBean> userList=adao.retriveAllUsers();
	Assert.assertNotNull(userList);
}

@After
public void destroy2()
{
	 adao=null;
}
@Before
public void init3()
{
	  adao=new AdminDao();
	  admin=new AdminBean("admin","admin","ADMIN");
	  user1="admin";
}
@Test
public void deleteUsers() throws IOException, InternalRecruitmentSystemException
{
	  int returnId=adao.deleteUsers(user1);
	  Assert.assertNotNull(returnId);
}

@After
public void destroy3()
{
	 adao=null;
}

}