package com.capegemini.irs.test;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.capegemini.irs.bean.EmployeeBean;
import com.capegemini.irs.bean.RequisitionBean;
import com.capgemini.irs.dao.RmgeDao;
import com.capgemini.irs.dao.RmgeDaoImpl;
import com.capgemini.irs.exception.InternalRecruitmentSystemException;
import com.capgemini.irs.util.DbUtility;

public class RmgeDaoTest

{
	 Connection conn=null;
	 RmgeDao rmdao=null;
	 String rid=null;
	 RequisitionBean rbean=null;
	 String rbean1=null;
	 String rmid3=null;
	 String rmid4=null;

@Before
public void init() throws IOException
{
	 conn=DbUtility.getConnect();
}
@Test
public void checkDbConnectivity()
{
	
	 Assert.assertNotNull(conn);
}

@After
public void destroy()
{
	 conn=null;
}
@Before
public void init1()
{
	 rmdao=null;	
	 rid="rm01";
}
@Test
public void  getParticularRequisition() throws IOException, InternalRecruitmentSystemException
{
	RequisitionBean hai = new RequisitionBean();
	rmdao = new RmgeDaoImpl();
	hai=rmdao.getParticularRequisition("rm01", "req01");
	Assert.assertNotNull(hai);

}
@After
public void destroy1()
{
    rmdao=null;
}

@Before
public void init6()
{
	 rmdao=new RmgeDaoImpl();
	 rbean=new RequisitionBean("req01", "rm01", "p02", "25-FEB-19", "25-FEB-19", "closed", "Analyst", "Level3", "JEE", '0');	 		
}
@Test
public void getEmployeeDetails() throws IOException, InternalRecruitmentSystemException
{

	List<EmployeeBean> empList=rmdao.getEmployeeDetails(rbean);
	Assert.assertNotNull(empList);
}

@After
public void destroy6()
{
    rmdao=null;
}

@Before
public void init7()
{
	 rmdao=new RmgeDaoImpl();
	 //rbean=new RequisitionBean("req02","rm01","p01" , "23-FEB-19","23-FEB-19","pending", "projectlead", "Level3", "JEE", "14");
	 	rmid3="rm01";	
}
@Test
public void getPendingRequisition() throws IOException, InternalRecruitmentSystemException
{

	List<RequisitionBean>  preqList=rmdao.getPendingRequisition(rmid3);
	Assert.assertNotNull(preqList);
}

@After
public void destroy7()
{
    rmdao=null;

}
@Before
public void init8()
{
	 rmdao=new RmgeDaoImpl();
	 //rbean=new RequisitionBean("req02","rm01","p01" , "23-FEB-19","23-FEB-19","pending", "projectlead", "Level3", "JEE", "14");
	 	rmid4="rm01";	
}
@Test
public void getClosedRequisition() throws IOException, InternalRecruitmentSystemException
{

	List<RequisitionBean>  preqList=rmdao.getClosedRequisition(rmid4);
	Assert.assertNotNull(preqList);
}

@After
public void destroy8()
{
    rmdao=null;

}
}
