package com.capegemini.irs.test;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.capegemini.irs.bean.ReqEmployee;
import com.capegemini.irs.bean.RequisitionBean;
import com.capgemini.irs.dao.RmgDaoImpl;
import com.capgemini.irs.exception.InternalRecruitmentSystemException;
import com.capgemini.irs.util.DbUtility;

public class RmgDaoTest
{
    Connection conn=null;
    RequisitionBean rbean=null;
	RmgDaoImpl rdao=null;
	String eid=null;
	String reqid=null;
	String reqId=null;
	String empId=null;
	String rmid2=null;
	String rmid1=null;

@Before
public void init() throws IOException
{
	 conn=DbUtility.getConnect();
}
@Test
public void checkDbConnectivity()
{
	
	 Assert.assertNotNull(conn);
}

@After
public void destroy()
{
	conn=null;
}
public void init1()
{
     rbean=new RequisitionBean("req02","rm01","p01" , "23-FEB-19","23-FEB-19","pending", "projectlead", "Level3", "JEE", "14");
     rdao=new RmgDaoImpl();
     reqId="req02";
	
}
public void retrieveDetails(String reqId) throws IOException, InternalRecruitmentSystemException
{
	List<ReqEmployee> empList=rdao.retrieveDetails(reqId);
	Assert.assertNotNull(empList);
}
@After
public void destroy1()
{
	  rdao=null;
}


@Before
public void init2()
{
     rbean=new RequisitionBean();
     rdao=new RmgDaoImpl();
	reqId="req02";
}
public void retrieveDetails() throws IOException, InternalRecruitmentSystemException
{
	List<ReqEmployee> empList=rdao.retrieveDetails(reqId);
	Assert.assertNotNull(empList);
}
@After
public void destroy2()
{
	  rdao=null;
}
@Before
public void init3()
{
     rbean=new RequisitionBean("req03","rm02","p01" , "23-FEB-19","23-FEB-19","pending", "analyst", "level3", "JEE", "6");
     rdao=new RmgDaoImpl();
	
}
public void raiseRequisition() throws IOException, InternalRecruitmentSystemException
{
	  int returnId=rdao.raiseRequisition(rbean);
	  Assert.assertEquals(1, returnId);
}
@After
public void destroy3()
{
	  rdao=null;
}
/*@Before
public void init4()
{
	
    rdao=new RmgDaoImpl();
    eid="E01";
    reqid="req01";
}
@Test
public void getEmployeeDetails() throws IOException, InternalRecruitmentSystemException
{
	 boolean returnId=rdao.getEmployeeDetails(eid, reqid);
	 Assert.assertTrue(returnId);
}
@After
public void destroy4()
{
	  rdao=null;
} */
@Before
public void init5()
{	
     rdao=new RmgDaoImpl();
     empId="E14";
     reqId="req01";
}
@Test
public void rejectRes() throws IOException, InternalRecruitmentSystemException
{
	 boolean returnId=rdao.rejectRes(empId, reqId);
	 Assert.assertTrue(returnId);
}
@After
public void destroy5()
{
	rdao=null;
}
@Before
public void init6()
{
	
    rdao=new RmgDaoImpl();
    rmid1="rm01";
    
}
@Test
public void getRequisitionByStatus() throws IOException, InternalRecruitmentSystemException
{

	  List<RequisitionBean> returnId=rdao.getRequisitionByStatus(rmid1);
	  Assert.assertNotNull(returnId);
}
@After
public void destroy6()
{
	  rdao=null;
} 
@Before
public void init7()
{
	
    rdao=new RmgDaoImpl();
    rmid2="rm01";
    
}
@Test
public void getRequisitionByStatusClosed() throws IOException, InternalRecruitmentSystemException 
{

	  List<RequisitionBean> returnId=rdao.getRequisitionByStatusClosed(rmid2);
	  Assert.assertNotNull(returnId);
}
@After
public void destroy7()
{
	  rdao=null;
} 
}
