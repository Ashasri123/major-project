package com.capgemini.irs.exception;

public class InternalRecruitmentSystemException extends Exception{
	public InternalRecruitmentSystemException() {
		super();
		
	}

	public InternalRecruitmentSystemException(String message) {
		super(message);
		
	}
}
