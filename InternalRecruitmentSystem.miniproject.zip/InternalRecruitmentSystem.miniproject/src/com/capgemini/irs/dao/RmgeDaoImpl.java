package com.capgemini.irs.dao;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import com.capgemini.irs.exception.InternalRecruitmentSystemException;
import org.omg.Messaging.SyncScopeHelper;

import com.capegemini.irs.bean.EmployeeBean;
import com.capegemini.irs.bean.RequisitionBean;
import com.capgemini.irs.util.DbUtility;

public class RmgeDaoImpl implements RmgeDao {
Connection conn=null;
RequisitionBean rbean=null;
private static Logger lg= Logger.getLogger("LoggerForRmgeDaoClass");
/*******************************************************************************************************

- Function Name	    :	getParticularRequisition()

- Return Type		:	RequisitionBean

- Author	     	:	Tejaswi

- Creation Date	    :	15/02/2019

- Description		:	getting requisition details

********************************************************************************************************/

	@Override
	public RequisitionBean getParticularRequisition(String rid,String reqId) throws IOException, InternalRecruitmentSystemException {
	conn=DbUtility.getConnect();
	try {
		PreparedStatement prepare=conn.prepareStatement(IQueryMapper.searchRequisition);
		prepare.setString(1, rid);
		prepare.setString(2, reqId);
	ResultSet rs=prepare.executeQuery();
	while(rs.next()) {
		rbean=new RequisitionBean();
		rbean.setRequisitionId(rs.getString(1));
		rbean.setRmId(rs.getString(2));
		rbean.setProjectId(rs.getString(3));
		rbean.setStartDate(rs.getString(4));
		rbean.setClosingDate(rs.getString(5));
		rbean.setCurrentStatus(rs.getString(6));
		rbean.setVacancyName(rs.getString(7));
		rbean.setSkill(rs.getString(8));
		rbean.setDomain(rs.getString(9));
		rbean.setNumberRequired(rs.getString(10));
		//System.out.println(rbean);
	}
	} catch (SQLException e) {
		lg.error("unable to get requisition details");
		throw new InternalRecruitmentSystemException("Unable to requisition details from database!!!" + e.getMessage()); 
		
	}

		return rbean;
	}
	/*******************************************************************************************************

	- Function Name	    :	getEmployeeDetails()

	- Return Type		:	List<EmployeeBean>

	- Author	     	:	Tejaswi

	- Creation Date	    :	15/02/2019

	- Description		:	getting employee details.

	********************************************************************************************************/

	@Override
	public List<EmployeeBean> getEmployeeDetails(RequisitionBean rbean) throws IOException, InternalRecruitmentSystemException {
	conn=DbUtility.getConnect();
	List<EmployeeBean> empList=null;
	EmployeeBean empBean=null;
	
	try {
		PreparedStatement prepare1=conn.prepareStatement(IQueryMapper.searchEmployee);		
		String skill=rbean.getSkill();		
		String domain=rbean.getDomain();		
		prepare1.setString(1, skill);
		prepare1.setString(2,domain);
		ResultSet rs1=prepare1.executeQuery();
		empList =new ArrayList<>();		
		
		while(rs1.next()) {
			
			empBean=new EmployeeBean();
			empBean.setEmployeeId(rs1.getString(1));
			empBean.setEmployeeName(rs1.getString(2));
			empBean.setProjectId(rs1.getString(3));
			empBean.setSkill(rs1.getString(4));
			empBean.setDomain(rs1.getString(5));
			empBean.setExperience(rs1.getInt(6));
			empList.add(empBean);
			
			
		}
	} catch (SQLException e) {
		lg.error("unable to get employee details");
		throw new InternalRecruitmentSystemException("Unable to get employee details from database!!!" + e.getMessage()); 
		
	}
		
		return empList;
	}
	/*******************************************************************************************************

	- Function Name	    :	getAllRequisitions()

	- Return Type		:	List<RequisitionBean>

	- Author	     	:	Tejaswi

	- Creation Date	    :	15/02/2019

	- Description		:	getting all requisitions.

	********************************************************************************************************/


	@Override
	public List<RequisitionBean> getAllRequisition() throws IOException, InternalRecruitmentSystemException {
		conn=DbUtility.getConnect();
		List<RequisitionBean> reqList=null;
		RequisitionBean reqBean=null;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.showAllRequisitions);
			ResultSet rs=pst.executeQuery();
			
			reqList=new ArrayList<>();
			while(rs.next())
				{
				
				reqBean = new RequisitionBean(rs.getString(1), rs.getString(2),rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8),rs.getString(9),rs.getString(10)); 
				reqList.add(reqBean);
				}
			
		} catch (SQLException e) {
			
			lg.error("unable to get all requisition details");
			throw new InternalRecruitmentSystemException("Unable to get all requisition details from database!!!" + e.getMessage()); 
		}
		return reqList;
	}
	/*******************************************************************************************************

	- Function Name	    :	getPendingRequisition()

	- Return Type		:	List<RequisitionBean>

	- Author	     	:	Tejaswi

	- Creation Date	    :	15/02/2019

	- Description		:	getting  pending requisition details by requisition status.

	********************************************************************************************************/

	@Override
	public List<RequisitionBean> getPendingRequisition(String rmid3) throws IOException, InternalRecruitmentSystemException {
		conn=DbUtility.getConnect();
		List<RequisitionBean> preqList=null;
		RequisitionBean preqBean=null;
		try {
			preqList=new ArrayList<RequisitionBean>();
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.showPendingRequisitions);
			pst.setString(1, rmid3);			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				preqBean = new RequisitionBean(rs.getString(1), rs.getString(2),rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8),rs.getString(9),rs.getString(10)); 
				preqList.add(preqBean);
			}
			
		} catch (SQLException e) {
			lg.error("unable to get pending requisition details");
			throw new InternalRecruitmentSystemException("Unable to get pending requisition details from database!!!" + e.getMessage()); 
		}
		
		return preqList;
	}
	/*******************************************************************************************************

	- Function Name	    :	getRequisitionByStatus()

	- Return Type		:	List<RequisitionBean>

	- Author	     	:	Tejaswi

	- Creation Date	    :	15/02/2019

	- Description		:	getting closed  requisition details by requisition status.

	********************************************************************************************************/


	@Override
	public List<RequisitionBean> getClosedRequisition(String rmid4) throws IOException, InternalRecruitmentSystemException
	{
		conn=DbUtility.getConnect();
		List<RequisitionBean> creqList=null;
		RequisitionBean creqBean=null;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.getRequisitionByStatusClosed2);
			pst.setString(1,rmid4);
			ResultSet rs=pst.executeQuery();
			creqList=new ArrayList<>();
			while(rs.next())
			{
				creqBean = new RequisitionBean(rs.getString(1), rs.getString(2),rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8),rs.getString(9),rs.getString(10)); 
				creqList.add(creqBean);
			}
			
		} catch (SQLException e) {
			lg.error("unable to get closed rrequisition details");
			throw new InternalRecruitmentSystemException("Unable to get closed requisition details from database!!!" + e.getMessage()); 
		}
		return creqList;
	}
	/*******************************************************************************************************

	- Function Name	    :	StoreEmployeeDetails()

	- Return Type		:	integer

	- Author	     	:	Tejaswi

	- Creation Date	    :	15/02/2019

	- Description		:	inserting employee details.

	********************************************************************************************************/


	@Override
	public int storeEmployeeDetails(List<EmployeeBean> employeeList, RequisitionBean rbean) throws IOException, InternalRecruitmentSystemException {
	
		int res = 0;
		for (EmployeeBean employeeBean : employeeList) {
			conn=DbUtility.getConnect();
			
			try {
				PreparedStatement pst = conn.prepareStatement(IQueryMapper.storeEmployeeDetails);
				pst.setString(1, rbean.getRequisitionId());
				pst.setString(2, employeeBean.getEmployeeId());
				pst.setString(3, employeeBean.getEmployeeName());
				pst.setString(4, employeeBean.getProjectId());
				pst.setString(5, employeeBean.getSkill());
				pst.setString(6, employeeBean.getDomain());
				pst.setInt(7, employeeBean.getExperience());
				res = pst.executeUpdate();
			
			}  catch (SQLIntegrityConstraintViolationException e) {
				System.out.println("please insert unique values");
			}
			catch (SQLException e) {
				lg.error("unable to insert employee details into database");
				throw new InternalRecruitmentSystemException("Unable to insert employee details into database!!!" + e.getMessage());
			}
			
		}
		return res;
	}

	

}
