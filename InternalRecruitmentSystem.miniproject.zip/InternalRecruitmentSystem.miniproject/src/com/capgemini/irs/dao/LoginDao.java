package com.capgemini.irs.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import com.capegemini.irs.bean.AdminBean;
import com.capgemini.irs.util.DbUtility;
import com.capgemini.irs.exception.InternalRecruitmentSystemException;

public class LoginDao implements ILoginDao{
	private static Logger lg= Logger.getLogger("LoggerForLoginDaoClass");
	ResultSet rs = null;
	boolean b1;
	boolean b2;
	boolean b3;
	/*******************************************************************************************************

	- Function Name	    :	checkUserDetails()

	- Return Type		:	AdminBean

	- Author	     	:	Asha

	- Creation Date	    :	15/02/2019

	- Description		:	checking user credentials from database

	********************************************************************************************************/

	@Override
	public AdminBean checkUserDetails(AdminBean admin) throws IOException, InternalRecruitmentSystemException {
		Connection con = null;
		AdminBean admin1=null;
		
		con = DbUtility.getConnect();
		try {
			PreparedStatement pst = con.prepareStatement(IQueryMapper.getUserDetails);
			pst.setString(1, admin.getRole());
			
			 rs = pst.executeQuery();
			 
			if(rs.next()) {
				
				
			admin1=new AdminBean(rs.getString(1),rs.getString(2), rs.getString(3));
				
			}
		} 
		catch (SQLException e) {
			lg.error("unable to fetch data from databaase");
			throw new InternalRecruitmentSystemException("Unable to fetch data from database!!!" + e.getMessage()); 		}
		return admin1;
		
	}

}
