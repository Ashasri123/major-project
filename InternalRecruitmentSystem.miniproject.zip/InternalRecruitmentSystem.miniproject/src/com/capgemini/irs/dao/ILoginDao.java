package com.capgemini.irs.dao;

import java.io.IOException;

import com.capegemini.irs.bean.AdminBean;
import com.capgemini.irs.exception.InternalRecruitmentSystemException;

public interface ILoginDao {

	AdminBean checkUserDetails(AdminBean admin) throws IOException, InternalRecruitmentSystemException;

	
}
