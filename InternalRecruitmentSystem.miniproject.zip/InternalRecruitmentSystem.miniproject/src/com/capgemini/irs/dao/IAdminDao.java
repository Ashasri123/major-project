package com.capgemini.irs.dao;

import java.io.IOException;
import java.util.List;

import com.capegemini.irs.bean.AdminBean;
import com.capgemini.irs.exception.InternalRecruitmentSystemException;

public interface IAdminDao {

	int addUsers(AdminBean admin) throws IOException, InternalRecruitmentSystemException;

	List<AdminBean> retriveAllUsers() throws IOException, InternalRecruitmentSystemException;

	int deleteUsers(String user1) throws IOException, InternalRecruitmentSystemException;

}
