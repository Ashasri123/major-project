package com.capgemini.irs.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.capegemini.irs.bean.ProjectBean;
import com.capegemini.irs.bean.ReqEmployee;
import com.capegemini.irs.bean.RequisitionBean;
import com.capgemini.irs.exception.InternalRecruitmentSystemException;

public interface IRmgDao {

	int raiseRequisition(RequisitionBean rbean) throws IOException, InternalRecruitmentSystemException;

	List<ReqEmployee> retrieveDetails(String reqId) throws IOException, InternalRecruitmentSystemException;

	boolean getEmployeeDetails(String eid, String reqId) throws IOException, InternalRecruitmentSystemException;
	public boolean rejectRes(String empId,String reqId1) throws IOException, InternalRecruitmentSystemException;

	List<ProjectBean> getProjectDetails(String rid) throws IOException, InternalRecruitmentSystemException;

	List<RequisitionBean> getRequisitionByStatus(String rmid1) throws IOException, InternalRecruitmentSystemException;

	List<RequisitionBean> getRequisitionByStatusClosed(String rmid2) throws IOException, InternalRecruitmentSystemException;

	int getVacancies(String req) throws IOException;
}
