package com.capgemini.irs.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.capgemini.irs.exception.InternalRecruitmentSystemException;

import org.apache.log4j.Logger;
import com.capegemini.irs.bean.AdminBean;
import com.capgemini.irs.util.DbUtility;

public class AdminDao implements IAdminDao

{
Connection conn=null;
private static Logger lg= Logger.getLogger("LoggerForAdminDaoClass");
/*******************************************************************************************************

- Function Name	    :	addUsers()

- Return Type		:	integer

- Author	     	:	Asha

- Creation Date	    :	15/02/2019

- Description		:	Adding Users

********************************************************************************************************/


	@Override
	public int addUsers(AdminBean admin) throws IOException,InternalRecruitmentSystemException
	{
		conn=DbUtility.getConnect();
		int status=0;
		
		try {
			PreparedStatement prepare=conn.prepareStatement(IQueryMapper.addUsers);
			prepare.setString(1, admin.getUserId());
			prepare.setString(2, admin.getPassword());
			prepare.setString(3, admin.getRole());
			status=prepare.executeUpdate();
		} catch (SQLException e) {
			lg.error("unable to insert data");
			throw new InternalRecruitmentSystemException("Unable to insert user details into database!!!" + e.getMessage()); 
		}
		return status;
	}
	/*******************************************************************************************************

	- Function Name	    :	retriveAllUsers()

	- Return Type		:	List<String>

	- Author	     	:	Asha

	- Creation Date	    :	15/02/2019

	- Description		:	Retrieve all  Users

	********************************************************************************************************/

	@Override
	public List<AdminBean> retriveAllUsers() throws IOException,InternalRecruitmentSystemException {
		conn=DbUtility.getConnect();
		List<AdminBean> userList=null;
		AdminBean admin=null;
		try {
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery(IQueryMapper.retriveUsers);
			userList=new ArrayList();
			 
			while(rs.next()) {
				 
				admin=new AdminBean(rs.getString(1),rs.getString(2),rs.getString(3));
					
					 userList.add(admin);
					 
				 
			}
		} catch (SQLException e) {
			lg.error("unable to fetch details from database");
			throw new InternalRecruitmentSystemException("Unable to fetch user details from database!!!" + e.getMessage()); 
		}
		return userList;
	}
	/*******************************************************************************************************

	- Function Name	    :	deleteUsers()

	- Return Type		:	integer

	- Author	     	:	Asha

	- Creation Date	    :	15/02/2019

	- Description		:	deleting Users from database

	********************************************************************************************************/

	@Override
	public int deleteUsers(String user1) throws IOException,InternalRecruitmentSystemException {
		int status1=0;
		conn=DbUtility.getConnect();
		try {
			PreparedStatement prepare=conn.prepareStatement(IQueryMapper.deleteUsers);
			prepare.setString(1, user1);
			status1=prepare.executeUpdate();
			
			
		} catch (SQLException e) {
			lg.error("unable to delete user details");
			throw new InternalRecruitmentSystemException("Unable to delete user details from database!!!" + e.getMessage()); 
		}
		return status1;
	}

}
