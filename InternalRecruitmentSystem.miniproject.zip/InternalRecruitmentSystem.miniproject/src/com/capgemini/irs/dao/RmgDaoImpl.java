package com.capgemini.irs.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import com.capegemini.irs.bean.ProjectBean;
import com.capegemini.irs.bean.ReqEmployee;
import com.capegemini.irs.bean.RequisitionBean;
import com.capgemini.irs.util.DbUtility;
import com.capgemini.irs.exception.InternalRecruitmentSystemException;

public class RmgDaoImpl implements IRmgDao {
	Connection conn=null;
	private static Logger lg= Logger.getLogger("LoggerForRmgDaoClass");
	/*******************************************************************************************************

	- Function Name	    :	raiserequisition()

	- Return Type		:	integer

	- Author	     	:	Urmila

	- Creation Date	    :	15/02/2019

	- Description		:	Raising requisition for vacancies in project.

	********************************************************************************************************/

	@Override
	public int raiseRequisition(RequisitionBean rbean1) throws IOException, InternalRecruitmentSystemException {
		conn=DbUtility.getConnect();
		int status2=0;
		
		try {
			PreparedStatement prepare=conn.prepareStatement(IQueryMapper.raiseRequisition);
			prepare.setString(1,rbean1.getRequisitionId() );
			prepare.setString(2,rbean1.getRmId() );
			prepare.setString(3,rbean1.getProjectId() );
			prepare.setString(4,rbean1.getVacancyName() );
			prepare.setString(5,rbean1.getSkill());
			prepare.setString(6,rbean1.getDomain() );
			prepare.setString(7,(String) rbean1.getNumberRequired() );
			status2=prepare.executeUpdate();
		} catch (SQLException e) {
			lg.error("unable to insert requisition details");
			throw new InternalRecruitmentSystemException("Unable to insert requisition details into database!!!" + e.getMessage()); 
		}
		return status2;
	}
	/*******************************************************************************************************

	- Function Name	    :	retrieveDetails()

	- Return Type		:	integer

	- Author	     	:	Urmila

	- Creation Date	    :	15/02/2019

	- Description		:    Retrieve matching employee details from data base

	********************************************************************************************************/

	@Override
	public List<ReqEmployee> retrieveDetails(String reqId) throws IOException, InternalRecruitmentSystemException 
	{
		conn=DbUtility.getConnect();
		List<ReqEmployee> empList=null;
		PreparedStatement pst;
		try {
			pst = conn.prepareStatement(IQueryMapper.retrieveDetails);
			pst.setString(1,reqId);
			ResultSet rs=pst.executeQuery();
			empList=new ArrayList<>();
			ReqEmployee bean=null;
			//System.out.println(rs.next());
			while(rs.next())
			{
				bean=new ReqEmployee(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getInt(7));
				//System.out.println("Hai");
				empList.add(bean);
				//System.out.println(empList);
			}
		} catch (SQLException e) {
			
			lg.error("unable to retrive employee details");
			throw new InternalRecruitmentSystemException("Unable to retrieve employee details based on requisition from database!!!" + e.getMessage());
		}
		
		return empList;
	}
	/*******************************************************************************************************

	- Function Name	    :	getEmployeeDetails()

	- Return Type		:	integer

	- Author	     	:	Urmila

	- Creation Date	    :	15/02/2019

	- Description		:	Getting employee details and selecting the employee

	********************************************************************************************************/

	@Override
	public boolean getEmployeeDetails(String eid, String reqId) throws IOException, InternalRecruitmentSystemException {
		boolean result2=false;;
	
		conn=DbUtility.getConnect();
		PreparedStatement pst=null;
		try {
			pst=conn.prepareStatement(IQueryMapper.getrequisition);
			pst.setString(1, reqId);
			ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				int availableVacancies=rs.getInt(10);
				String proId=rs.getString(3);
				System.out.println("Available vacancies:"+availableVacancies);
				System.out.println("Project id is:"+proId);
				if(availableVacancies>0) {
					 result2=updateEmpProjId(eid,proId);
					
				}
			
				if(result2==true) {
				--availableVacancies;
				pst=conn.prepareStatement(IQueryMapper.updateVacancies);
				pst.setInt(1,availableVacancies );
				pst.setString(2, reqId);
				int status3=pst.executeUpdate();
				if(status3!=0) {
					if(availableVacancies==0) {
					
						pst=conn.prepareStatement(IQueryMapper.updateRequisionStatus);
						pst.setString(1, reqId);
						int status4=pst.executeUpdate();
						if(status4>0) {
							System.out.println("requistion closed");
						}
						else {
							System.out.println("requistion pending");
						}
					}
					else {
						System.out.println("vacancies are available: " + availableVacancies);
					}
				}
				else {
					System.out.println("vacancies are not updated");
				}
			}else {
					System.out.println("invalid employee Id ");
					System.exit(0);
				}
				//result2=true;
		} 
			else {
				System.out.println("no data available");
			}
		}catch (SQLException e) {
			lg.error("unable to get employee details from db");
			throw new InternalRecruitmentSystemException("Unable to get employee details from database!!!" + e.getMessage()); 
		}
		return result2;
	}
	/*******************************************************************************************************

	- Function Name	    :	updateEmpProjId()

	- Return Type		:	boolean

	- Author	     	:	Urmila

	- Creation Date	    :	15/02/2019

	- Description		:	Updating project Id of the Employee

	********************************************************************************************************/

	private boolean updateEmpProjId(String eid, String proId) throws IOException, InternalRecruitmentSystemException {
		conn=DbUtility.getConnect();
		int status6=0;
		int delEmpStatus=0;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.updateprojectid);
			pst.setString(1, proId);
			pst.setString(2, eid);
			status6=pst.executeUpdate();
			if(status6 > 0) {
				PreparedStatement pst1  = conn.prepareStatement(IQueryMapper.deleteEmployeeFromReqEmp);
				pst1.setString(1, eid);
				delEmpStatus = pst1.executeUpdate();
				if(delEmpStatus < 0) {
					System.out.println("unable to delete employee from reqemployee table");
				}
			}
			 
			 
			 
		
		} catch (SQLException e) {
			lg.error("unable to update project Id in employee table");
			throw new InternalRecruitmentSystemException("Unable to update project Id in employee table in database!!!" + e.getMessage()); 
		}
		if(status6>0) {
			return true;
		}
		else {
			return false;
		}
		
		
	}
	/*******************************************************************************************************

	- Function Name	    :	rejectRes()

	- Return Type		:	boolean

	- Author	     	:	Urmila

	- Creation Date	    :	15/02/2019

	- Description		:	Rejecting the employees

	********************************************************************************************************/

	public boolean rejectRes(String empId,String reqId1) throws IOException, InternalRecruitmentSystemException  {

		

		boolean result = false;

		result = updateEmpProjId(empId,"rmg");

		return result;

	}
	/*******************************************************************************************************

	- Function Name	    :	getProjectDetails()

	- Return Type		:	integer

	- Author	     	:	Urmila

	- Creation Date	    :	15/02/2019

	- Description		:	getting project details

	********************************************************************************************************/

	@Override
	public List<ProjectBean> getProjectDetails(String rid) throws IOException, InternalRecruitmentSystemException {
		conn=DbUtility.getConnect();
		ProjectBean pbean=null;
		List<ProjectBean> plist=null;
		try {
			PreparedStatement pst4=conn.prepareStatement(IQueryMapper.getProjectDetails);
			pst4.setString(1, rid);
			ResultSet rs=pst4.executeQuery();
			plist=new ArrayList<ProjectBean>();
			while(rs.next()) {
				pbean=new ProjectBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
				plist.add(pbean);
			}
		} catch (SQLException e) {
			lg.error("unable to get project details");
			throw new InternalRecruitmentSystemException("Unable to get project details from database!!!" + e.getMessage());
		}
		return plist;
	}
	/*******************************************************************************************************

	- Function Name	    :	getRequisitionByStatus()

	- Return Type		:	List<RequisitionBean>

	- Author	     	:	Urmila

	- Creation Date	    :	15/02/2019

	- Description		:	getting requisition details by requisition status.

	********************************************************************************************************/

	@Override
	public List<RequisitionBean> getRequisitionByStatus(String rmid1) throws IOException, InternalRecruitmentSystemException {
		conn=DbUtility.getConnect();
		List<RequisitionBean> rlist1=null;
		try {
			PreparedStatement pst5=conn.prepareStatement(IQueryMapper.getRequisitionByStatus);
			pst5.setString(1, rmid1);			
			ResultSet rs=pst5.executeQuery();
			rlist1=new ArrayList<RequisitionBean>();
			RequisitionBean rbean1=null;
			while(rs.next()) {		
				
				rbean1=new RequisitionBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10));
				
				rlist1.add(rbean1);
			}
		} catch (SQLException e) {
			lg.error("unable to get pending requisitions");
			throw new InternalRecruitmentSystemException("Unable to get pending requisition details from database!!!" + e.getMessage()); 
		}
		return rlist1;
	}
	/*******************************************************************************************************

	- Function Name	    :	getRequisitionByStatusClosed()

	- Return Type		:	List<RequisitionBean>

	- Author	     	:	Urmila

	- Creation Date	    :	15/02/2019

	- Description		:	getting closed requisition details by requisition status.

	********************************************************************************************************/

	
	@Override
	public List<RequisitionBean> getRequisitionByStatusClosed(String rmid2) throws IOException, InternalRecruitmentSystemException {
		conn=DbUtility.getConnect();
		List<RequisitionBean> rlist2=null;
		try {
			PreparedStatement pst5=conn.prepareStatement(IQueryMapper.getRequisitionByStatusClosed);
			pst5.setString(1, rmid2);
			
			
			
			ResultSet rs=pst5.executeQuery();
			rlist2=new ArrayList<RequisitionBean>();
			RequisitionBean rbean1=null;
			while(rs.next()) {
		
				
		rbean1=new RequisitionBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10));
		rlist2.add(rbean1);
			}
		} catch (SQLException e) {
			lg.error("unable to get closed requisition details");
			throw new InternalRecruitmentSystemException("Unable to get closed requisition details from database!!!" + e.getMessage()); 
		}
		return rlist2;
		
	}
	@Override
	public int getVacancies(String req) throws IOException {
		conn=DbUtility.getConnect();
		int vacancies = 0;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.getVacancies);
			pst.setString(1, req);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				
				vacancies = rs.getInt(10);
				
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return vacancies;
	}
	

}
