package com.capgemini.irs.dao;

import java.io.IOException;
import java.util.List;

import com.capegemini.irs.bean.EmployeeBean;
import com.capegemini.irs.bean.RequisitionBean;
import com.capgemini.irs.exception.InternalRecruitmentSystemException;

public interface RmgeDao {

	RequisitionBean getParticularRequisition(String rid, String reqId) throws IOException, InternalRecruitmentSystemException;

	List<EmployeeBean> getEmployeeDetails(RequisitionBean rbean) throws IOException, InternalRecruitmentSystemException;

	List<RequisitionBean> getAllRequisition() throws IOException, InternalRecruitmentSystemException;

	List<RequisitionBean> getPendingRequisition(String rmid3) throws IOException, InternalRecruitmentSystemException;

	List<RequisitionBean> getClosedRequisition(String rmid4) throws IOException, InternalRecruitmentSystemException;

	int storeEmployeeDetails(List<EmployeeBean> employeeList, RequisitionBean rbean) throws IOException, InternalRecruitmentSystemException;

}
