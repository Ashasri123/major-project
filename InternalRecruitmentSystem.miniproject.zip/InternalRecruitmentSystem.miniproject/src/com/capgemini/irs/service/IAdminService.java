package com.capgemini.irs.service;

import java.io.IOException;
import java.util.List;

import com.capegemini.irs.bean.AdminBean;
import com.capegemini.irs.bean.RequisitionBean;
import com.capgemini.irs.exception.InternalRecruitmentSystemException;

public interface IAdminService {

	int addUser(AdminBean admin) throws IOException, InternalRecruitmentSystemException;

	List<AdminBean> retriveAllUsers() throws IOException, InternalRecruitmentSystemException;

	int deleteUsers(String user1) throws IOException, InternalRecruitmentSystemException;

	boolean choiceValidation(CharSequence choice);



	boolean choiceValidationrmge(CharSequence choice);


	boolean validateId(String user, String userRole);

	boolean validateRole(String userRole);

	

}
