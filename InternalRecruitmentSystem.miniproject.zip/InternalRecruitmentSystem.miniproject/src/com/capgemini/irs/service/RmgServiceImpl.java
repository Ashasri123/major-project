package com.capgemini.irs.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capegemini.irs.bean.ProjectBean;
import com.capegemini.irs.bean.ReqEmployee;
import com.capegemini.irs.bean.RequisitionBean;
import com.capgemini.irs.dao.IRmgDao;
import com.capgemini.irs.dao.RmgDaoImpl;
import com.capgemini.irs.exception.InternalRecruitmentSystemException;

public class RmgServiceImpl implements IRmgService {
IRmgDao rmDao=null;
static Matcher u;
	@Override
	public int raiseRequisition(RequisitionBean rbean) throws IOException, InternalRecruitmentSystemException {
		rmDao=new RmgDaoImpl();
		return rmDao.raiseRequisition(rbean);
	}
	
	@Override
	public List<ReqEmployee> retrieveDetails(String reqId) throws IOException, InternalRecruitmentSystemException {
		rmDao=new RmgDaoImpl();
		return rmDao.retrieveDetails(reqId);
		
		
	}

	@Override
	public boolean selectEmployee(String eid, String reqId) throws IOException, InternalRecruitmentSystemException {
		rmDao=new RmgDaoImpl();
		boolean b=rmDao.getEmployeeDetails(eid,reqId);
		return b;
	}

	@Override
	public boolean rejectRes(String empId, String reqId1) throws IOException, InternalRecruitmentSystemException {
		rmDao=new RmgDaoImpl();
		boolean b1=rmDao.rejectRes(empId, reqId1);
		return b1;
	}

	@Override
	public List<ProjectBean> getProjectDetails(String rid) throws IOException, InternalRecruitmentSystemException {
		rmDao=new RmgDaoImpl();
		return rmDao.getProjectDetails(rid);
	}

	@Override
	public List<RequisitionBean> getRequisitionByStatus(String rmid1) throws IOException, InternalRecruitmentSystemException {
		rmDao=new RmgDaoImpl();
		return rmDao.getRequisitionByStatus(rmid1);
	}

	@Override
	public List<RequisitionBean> getRequisitionByStatusClosed(String rmid2) throws IOException, InternalRecruitmentSystemException {
		rmDao=new RmgDaoImpl();
		return rmDao.getRequisitionByStatusClosed(rmid2);
	}

	@Override
	public boolean validateReqName(String vname) {
		Pattern v= Pattern.compile("[A-z]{1}[a-z]{2,20}");
		 u = v.matcher(vname);
		if(!u.matches())
			{
				System.out.println("enter valid vacancy");
				return false;
			}
		else {
			return true;
		}
	}

	@Override
	public boolean validateSkill(String skill) {
		Pattern v= Pattern.compile("[A-Z|a-z]{1}[a-z]{2,10}[0-9]{1}");
		 u = v.matcher(skill);
		if(!u.matches())
			{
				System.out.println("enter valid skill");
				return false;
			}
		else {
			return true;
		}
		
	}

	@Override
	public boolean choiceValidationrmg(CharSequence choice1) {
		Pattern v= Pattern.compile("[0-9]{1}");
		u=v.matcher(choice1);
		if(!u.matches())
		{
			System.out.println("enter valid choice");
			return false;
		}
		else {
		return true;
		}
	}

	@Override
	public boolean validateReqId(String req) {
		Pattern v= Pattern.compile("[r]{1}[e]{1}[q]{1}[0-9]{2}");
		u=v.matcher(req);
		if(!u.matches())
		{
			System.out.println("enter valid choice");
			return false;
		}
		else {
		return true;
		}
	}

	@Override
	public boolean validatermid(String rmid) {
		Pattern v= Pattern.compile("[r]{1}[m]{1}[0-9]{2}");
		u=v.matcher(rmid);
		if(!u.matches())
		{
			System.out.println("enter valid choice");
			return false;
		}
		else {
		return true;
	}
	}

	@Override
	public boolean validateDomain(String domain) {
		Pattern v= Pattern.compile("[A-Z|.|a-z]{1,10}");
		u=v.matcher(domain);
		if(!u.matches())
		{
			System.out.println("enter valid domain");
			return false;
		}
		else {
		return true;
	}
	}

	@Override
	public boolean validatevacancy(CharSequence vacancy) {
		Pattern v= Pattern.compile("[0-9]{1,}");
		u=v.matcher(vacancy);
		if(!u.matches())
		{
			System.out.println("enter valid domain");
			return false;
		}
		else {
		return true;
	}
	}

	@Override
	public boolean validateEid(String eid) {
		Pattern v= Pattern.compile("[E|e]{1}[0-9]{2}");
		u=v.matcher(eid);
		if(!u.matches())
		{
			System.out.println("enter valid Id");
			return false;
		}
		else {
		return true;
	}
		
	}

	@Override
	public int getVacancies(String req) throws IOException {
		rmDao=new RmgDaoImpl();
		return rmDao.getVacancies(req);
	}}



