package com.capgemini.irs.service;

import java.io.IOException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capegemini.irs.bean.EmployeeBean;
import com.capegemini.irs.bean.RequisitionBean;
import com.capgemini.irs.dao.RmgeDao;
import com.capgemini.irs.dao.RmgeDaoImpl;
import com.capgemini.irs.exception.InternalRecruitmentSystemException;

public class RmgeServiceImpl implements IRmgeService {
RmgeDao dao=null;
static Matcher u;
	@Override
	public RequisitionBean getParticularRequisition(String rid,String reqId) throws IOException, InternalRecruitmentSystemException {
		dao=new RmgeDaoImpl();
		return dao.getParticularRequisition(rid,reqId);
	}
	@Override
	public List<EmployeeBean> getEmployeeDetails(RequisitionBean rbean) throws IOException, InternalRecruitmentSystemException {
		dao=new RmgeDaoImpl();
		return dao.getEmployeeDetails(rbean);
	}
	@Override
	public List<RequisitionBean> getAllRequisition() throws IOException, InternalRecruitmentSystemException {
		dao=new RmgeDaoImpl();
		return dao.getAllRequisition();
	}
	@Override
	public List<RequisitionBean> getPendingRequisition(String rmid3) throws IOException, InternalRecruitmentSystemException {
		dao=new RmgeDaoImpl();
		return dao.getPendingRequisition(rmid3);
		
	}
	@Override
	public List<RequisitionBean> getClosedRequisition(String rmid4) throws IOException, InternalRecruitmentSystemException 
	{
		dao=new RmgeDaoImpl();
		return dao.getClosedRequisition(rmid4);
	}
	@Override
	public int storeEmployeeDetails(List<EmployeeBean> employeeList, RequisitionBean rbean) throws IOException, InternalRecruitmentSystemException {
		dao=new RmgeDaoImpl();
		return dao.storeEmployeeDetails(employeeList, rbean);
	}
	//@Override
	/*public boolean validateId(String rid) {
		Pattern v= Pattern.compile("[r]{1}[m]{1}[0-9]{3,5}");
		u=v.matcher(rid);
		if(!u.matches())
		{
			System.out.println("enter valid choice");
			return false;
		}
		else {
		return true;
	}
		
	}*/
	
}
