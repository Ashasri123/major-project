package com.capgemini.irs.service;

import java.io.IOException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capegemini.irs.bean.AdminBean;
import com.capgemini.irs.dao.AdminDao;
import com.capgemini.irs.dao.IAdminDao;
import com.capgemini.irs.exception.InternalRecruitmentSystemException;

public class AdminServiceImpl implements IAdminService{
IAdminDao dao=null;
static Matcher u;
	@Override
	public int addUser(AdminBean admin) throws IOException, InternalRecruitmentSystemException {
		dao=new AdminDao();
		return dao.addUsers(admin);
		
		
		
	}
	@Override
	public List<AdminBean> retriveAllUsers() throws IOException, InternalRecruitmentSystemException {
		dao=new AdminDao();
		return dao.retriveAllUsers();
	}
	@Override
	public int deleteUsers(String user1) throws IOException, InternalRecruitmentSystemException {
		dao=new AdminDao();
		return dao.deleteUsers(user1);
	}
	
	@Override
	public boolean choiceValidation(CharSequence choice) {
		Pattern v= Pattern.compile("[1-4]{1}");
		 u = v.matcher(choice);
		if(!u.matches())
			{
				System.out.println("enter valid choice");
				return false;
			}
		else {
			return true;
	}
	}
	
	@Override
	public boolean choiceValidationrmge(CharSequence choice) {
		Pattern v= Pattern.compile("[1-5]{1}");
		u=v.matcher(choice);
		if(!u.matches())
		{
			System.out.println("enter valid choice");
			return false;
		}
		else {
		return true;
	}
}
	@Override
	public boolean validateId(String user, String userRole) {
		if(userRole.equals("RMG"))
		{
			Pattern v= Pattern.compile("[r]{1}[m]{1}[0-9]{2}");
			u=v.matcher(user);
			if(!u.matches())
			{
				System.out.println("enter valid id");
				return false;
			}
			else 
			{
				return true;
			}
		}
		else if(userRole.equals("RMGE"))
		{

			Pattern v= Pattern.compile("[r]{1}[m]{1}[e]{1}[0-9]{2}");
			u=v.matcher(user);
			if(!u.matches())
			{
				System.out.println("enter valid id");
				return false;
			}
			else
			{
				return true;
			}
		}else {
		return false;
		}
		
	}
	@Override
	public boolean validateRole(String userRole) {
		Pattern v= Pattern.compile("[R]{1}[M]{1}[G]{1}|[R]{1}[M]{1}[G]{1}[E]{1}");
		u=v.matcher(userRole);
		if(!u.matches())
		{
			System.out.println("enter valid role");
			return false;
		}
		else {
		return true;
	}
	}

}
