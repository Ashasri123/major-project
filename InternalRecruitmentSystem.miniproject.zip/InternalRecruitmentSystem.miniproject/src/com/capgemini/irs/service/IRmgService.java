package com.capgemini.irs.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.capegemini.irs.bean.ProjectBean;
import com.capegemini.irs.bean.ReqEmployee;
import com.capegemini.irs.bean.RequisitionBean;
import com.capgemini.irs.exception.InternalRecruitmentSystemException;

public interface IRmgService {

	int raiseRequisition(RequisitionBean rbean) throws IOException, InternalRecruitmentSystemException;

	List <ReqEmployee> retrieveDetails(String reqId) throws IOException, InternalRecruitmentSystemException;

	boolean selectEmployee(String eid, String reqId) throws IOException, InternalRecruitmentSystemException;
	public boolean rejectRes(String empId,String reqId1) throws IOException, InternalRecruitmentSystemException;

	List<ProjectBean> getProjectDetails(String rid) throws IOException, InternalRecruitmentSystemException;

	List<RequisitionBean> getRequisitionByStatus(String rmid1) throws IOException, InternalRecruitmentSystemException;

	List<RequisitionBean> getRequisitionByStatusClosed(String rmid2) throws IOException, InternalRecruitmentSystemException;

	boolean validateReqName(String vname);

	boolean validateSkill(String skill);
	boolean choiceValidationrmg(CharSequence choice1);

	boolean validateReqId(String req);

	boolean validatermid(String rmid);

	boolean validateDomain(String domain);

	boolean validatevacancy(CharSequence vacancy);

	boolean validateEid(String eid);

	int getVacancies(String req) throws IOException;
    
}
