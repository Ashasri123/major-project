package com.capgemini.irs.service;

import java.io.IOException;

import com.capegemini.irs.bean.AdminBean;
import com.capgemini.irs.dao.ILoginDao;
import com.capgemini.irs.dao.LoginDao;
import com.capgemini.irs.exception.InternalRecruitmentSystemException;

public class LoginService implements ILoginService {

	@Override
	public AdminBean checkUserDetails(AdminBean admin) throws IOException, InternalRecruitmentSystemException {
		ILoginDao dao = new LoginDao();
		return dao.checkUserDetails(admin);
	}

}
