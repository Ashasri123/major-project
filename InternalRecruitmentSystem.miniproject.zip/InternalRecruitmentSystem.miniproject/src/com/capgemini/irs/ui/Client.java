package com.capgemini.irs.ui;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.capgemini.irs.service.IAdminService;
import com.capegemini.irs.bean.AdminBean;
import com.capegemini.irs.bean.EmployeeBean;
import com.capegemini.irs.bean.ProjectBean;
import com.capegemini.irs.bean.ReqEmployee;
import com.capegemini.irs.bean.RequisitionBean;
import com.capgemini.irs.exception.InternalRecruitmentSystemException;
import com.capgemini.irs.service.AdminServiceImpl;
import com.capgemini.irs.service.ILoginService;
import com.capgemini.irs.service.IRmgService;
import com.capgemini.irs.service.IRmgeService;
import com.capgemini.irs.service.LoginService;
import com.capgemini.irs.service.RmgServiceImpl;
import com.capgemini.irs.service.RmgeServiceImpl;

public class Client {
static Logger lg= Logger.getLogger("LoggerForMain");
static	IAdminService service=null;
static IRmgService rmService=null;
static IRmgeService rmgeService=null;
static AdminBean admin=null;
static  String fuser=null;
static Scanner sc = new Scanner(System.in);
static String role=null;
static boolean result;
static String user1;
static int c;
static String vname;
static String skill;
static String req;
static String rmid;
static String prId;
static String domain;
static CharSequence vacancy;
static String eid;
static String userRole;
static String user;
static String rid;
/*******************************************************************************************************

- Author	     	:	Sirish

- Creation Date	    :	15/02/2019

- Description		:	User Interface

********************************************************************************************************/

public static void main(String[] args) throws IOException, SQLException, InternalRecruitmentSystemException {
	PropertyConfigurator.configure("resources/log4j.properties");
	 admin=new AdminBean();
	List<AdminBean> userList=null;
	RequisitionBean rbean=null;
	int userStatus=0;
	int deleteStatus=0;
	System.out.println("*****Login Page*****");
	System.out.println("Enter UserName: ");
    String userName = sc.next();
	admin.setUserId(userName);
	System.out.println("Enter Password: ");
	String password = sc.next();
	admin.setPassword(password);
	System.out.println("Enter Role: ");
	role = sc.next();
	admin.setRole(role);
	AdminBean admin1;
    admin1=checkLoginDetails(admin);
   
    if(admin1!=null)
    {			 
		
	if(role.equals("ADMIN")) 
	{
	System.out.println("***********Welcome Admin*************");
		System.out.println("1.Add Users");
		System.out.println("2.Display User Details");
		System.out.println("3.Delete Users");
		System.out.println("4.Logout");
		enterChoice();
		switch(c) {
		case 1:
			admin = new AdminBean();
			service=new AdminServiceImpl();
			
			System.out.println("Enter User Id: ");
			String user=sc.next();
			admin.setUserId(user);
			/*do {
			
			service=new AdminServiceImpl();
			result=service.validateId(user,userRole);
			}while(result==false);*/
	        
	        
			System.out.println("Enter Password: ");
			String pass=sc.next();
			admin.setPassword(pass);
			
			System.out.println("Enter Role: ");
			userRole=sc.next();
			
			/*do {
	       result=service.validateRole(userRole);
			}while(result==false);*/
			admin.setRole(userRole);
			
			userStatus=service.addUser(admin);
			if(userStatus>0) {
				lg.info("Data inserted");
				System.out.println(userStatus + " data inserted.");
			}
			else {
				
				System.out.println("No data inserted");
				lg.error("No data inserted");
			}
			
			break;
		
		case 2:
			userList=new ArrayList();
			userList=service.retriveAllUsers();
			for (AdminBean adminBean : userList) {
				System.out.println(adminBean);
			}
			break;
		
		case 3:
	        deleteById();
			service=new AdminServiceImpl();
			deleteStatus=service.deleteUsers(user1);
			if(deleteStatus>0) {
				System.out.println("Particular user is deleted " + user1);
				lg.info("Data is deleted");
			}
			else {
				System.out.println("Id not found please enter valid id");
				deleteById();
				lg.error("No data deleted");
			}
			break;
		
		case 4:
			System.out.println("Successfully Logged Out!!!");
			System.exit(0);
			lg.info("Successfully logged out");
			break;
			
		default:
				System.out.println("Enter Valid Choice: ");
				enterChoice();
				break;
		}//switch
	}
		
	
	//IF
	//*************************RMG**************************************************
	else if(role.equals("RMG")) {
		System.out.println("***********Welcome RMG*************");
		System.out.println("1.Get Project Details");
		System.out.println("2.Raise Requisition in Projects");
		System.out.println("3.View and Accept  the Employees");
		System.out.println("4.Reject the Employees");
		System.out.println("5.Get Reports based on Pending Requisition Status");
		System.out.println("6.Get Reports based on closed Requisition Status");
		System.out.println("7.Logout");
			enterChoiceRmg();
			rbean=new RequisitionBean();
	
		switch(c) {
		
		case 1:
			
			do {
				System.out.println("Enter Your Id(ex:rm01): ");
				rmid=sc.next();
				rmService=new RmgServiceImpl();
				
				result=rmService.validatermid(rmid);
			}while(result==false);
			
			List<ProjectBean> plist=null;
			plist=rmService.getProjectDetails(rmid);
			if(!plist.isEmpty()) {
			for (ProjectBean projectBean : plist) {
				System.out.println(projectBean);
			}
			}
			else {
				System.out.println("Resource Manager Id is not valid");
			}
			break;
		
		case 2:
			int rmStatus=0;
			System.out.println("Enter Requisition Id(ex:req01): ");
			 req=sc.next();
			/*do {
			
			rmService=new RmgServiceImpl();
			result=rmService.validateReqId(req);
			}while(result==false);*/
			rbean.setRequisitionId(req);
			
			do {
			System.out.println("Enter Your Id(ex:rm01): ");
			rmid=sc.next();
			rmService=new RmgServiceImpl();
			result=rmService.validatermid(rmid);
			}while(result==false);
			rbean.setRmId(rmid);
		    
			do {
			System.out.println("Enter project Id(ex:p01): ");
			 prId=sc.next();
			rmService=new RmgServiceImpl();
			result=rmService.validatermid(rmid);
		    }while(result==false);
			rbean.setProjectId(prId);
			
			do {
				System.out.println("Enter Skill(ex:Level2): ");
				 skill=sc.next();
				 rmService=new RmgServiceImpl();
			     result=rmService.validateSkill(skill);
				}while(result==false);
				rbean.setSkill(skill);
			do {
				System.out.println("Enter Vacancy Name: ");
			     vname=sc.next();
			     rmService=new RmgServiceImpl();
			     result=rmService.validateReqName(vname);
			}while(result==false);
			rbean.setVacancyName(vname);
			
		
			
			do {
			System.out.println("Enter Domain: ");
		     domain=sc.next();
			rmService=new RmgServiceImpl();
		     result=rmService.validateDomain(domain);
			}while(result==false);
			rbean.setDomain(domain);
			
			do {
			System.out.println("Number of Vacancies Available: ");
			 vacancy=sc.next();
			rmService=new RmgServiceImpl();
		     result=rmService.validatevacancy(vacancy);
			}while(result==false);
			
			rbean.setNumberRequired(vacancy);
			rmStatus=rmService.raiseRequisition(rbean);
			if(rmStatus>0) {
				System.out.println(rmStatus+" requisition raised");
				lg.info("Requisition raised");
			}
			else {
				System.out.println("Unable to raise requisition");
				lg.error("No requision raised");
			}
			
			
			break;
			
		case 3:
		rmService=new RmgServiceImpl();
		
		
		do {
		System.out.println("Enter Requisition Id(ex:req01): ");
		 req=sc.next();
		 rmService=new RmgServiceImpl();
		result=rmService.validateReqId(req);
		}while(result==false);
		
		List<ReqEmployee> rempList= new ArrayList<>();
		rempList=rmService.retrieveDetails(req);
		//System.out.println(rempList);
		for (ReqEmployee reqEmployee : rempList) {
			System.out.println(reqEmployee);
		}
		if(!(rempList.isEmpty())) {
			
			int availableVacancies = rmService.getVacancies(req);
			if(availableVacancies>0) {
			
				do {
			
					System.out.println("Enter Employee Id(ex:E01): ");
					eid=sc.next();
					rmService=new RmgServiceImpl();
					result=rmService.validateEid(eid);
				}while(result==false);
			}
			else {
				System.out.println("No vacancies available for this requisition ");
			}
			
		
		
		boolean b=rmService.selectEmployee(eid,req);
		if(b==true) {
			System.out.println("Selected");
			lg.info("Selected");
		}
		else {
			System.out.println("Not selected");
			lg.info("Not selected");
		}
		}
		else {
			System.out.println("Invalid Requisition Id");
		}
		
		break;
		
		case 4:
			rmService=new RmgServiceImpl();
			
			do {
			System.out.println("Enter Requisition Id(ex:req01): ");
			req=sc.next();
			rmService=new RmgServiceImpl();
			result=rmService.validateReqId(req);
			}while(result==false);
			
			List<ReqEmployee> rempList1= new ArrayList<>();
			rempList1=rmService.retrieveDetails(req);
			for (ReqEmployee reqEmployee : rempList1) {
				System.out.println(reqEmployee);
			}
			
			do {
			System.out.println("Enter Employee Id(ex:E01): ");
			 eid=sc.next();
			 rmService=new RmgServiceImpl();
			result=rmService.validateEid(eid);
			}while(result==false);
			
			boolean b2=rejectRes(eid, req);
			if(b2==true) {
				System.out.println("Employee rejected successfully");
				lg.info("employee rejected");
			}
			else {
				System.out.println("Employee not rejected");
				lg.error("Employee not rejected");
			}
			
			break;
		case 5:
			System.out.println("Enter Your Id(ex:rm01): ");
			String rmid=sc.next();
			/*do {
			
			rmService=new RmgServiceImpl();
			result=rmService.validatermid(rmid);
			}while(result==false);
			*/
			List<RequisitionBean> rmstatus= new ArrayList<RequisitionBean>();					
			 rmstatus=rmService.getRequisitionByStatus(rmid);
			 if(!(rmstatus.isEmpty())) {
		
				for (RequisitionBean requisitionBean : rmstatus) {
					System.out.println(requisitionBean);
				}
			 }else {
				 System.out.println("No data found!!!");
			 }
			 break;
		
		case 6:
			System.out.println("Enter Your Id(ex:rm01): ");
			String rmgid=sc.next();
			/*
			do {
				
				rmService=new RmgServiceImpl();
				result=rmService.validatermid(rmid);
				}while(result==false);				
			*/
			 List<RequisitionBean> rmstatus2=new ArrayList<RequisitionBean>();
			 rmstatus2=rmService.getRequisitionByStatusClosed(rmgid);
			 if(!(rmstatus2.isEmpty())){
				 for (RequisitionBean requisitionBean : rmstatus2) {
					 System.out.println(requisitionBean);
				 }
			 }else {
				 System.out.println("No details found");
			 }
			break;
			
		case 7:
			System.out.println("Successfully Logged Out!!!");
			//System.exit(0);
			break;
			
		default:
			System.out.println("Enter Valid Choice: ");
			enterChoiceRmg();
			break;
		
			
		
		}
	}//else if
		
	
			
	//*************************RMGE**************************************************
	else if(role.equals("RMGE")) {		
		
		System.out.println("1.Get all requisitions and Search Employee Based on Requisition and Assign to RMG");		
		System.out.println("2.Get Requisitions Irrespective of RMG");
		System.out.println("3.Show Pending Requisitions");
		System.out.println("4.Show Closed Requisitions");
		System.out.println("5.Logout");
		enterChoiceRmge();
		
		switch(c) {
		
		case 1:
			rmgeService=new RmgeServiceImpl();
			List<RequisitionBean> reqList1=new ArrayList<RequisitionBean>();
			reqList1=rmgeService.getAllRequisition();
			for (RequisitionBean requisitionBean : reqList1) {
				System.out.println(requisitionBean);
			}	
			
			System.out.println("Enter Resource Manager Id(ex:rm01): ");
			rid=sc.next();
			System.out.println("Enter requisition Id");
			String reqId=sc.next();
			rmgeService=new RmgeServiceImpl();
		  
		/*	do {
			
			result=rmgeService.validateId(rid);
		    }while(result==false);*/
			
			rbean=new RequisitionBean();
			rbean=rmgeService.getParticularRequisition(rid,reqId);
			if(rbean!=null) {
			List<EmployeeBean>employeeList=new ArrayList<>();
			employeeList=rmgeService.getEmployeeDetails(rbean);
			for ( EmployeeBean employeeBean : employeeList) {
				System.out.println(employeeBean);
	              
			}
			int output = rmgeService.storeEmployeeDetails(employeeList, rbean);
			//System.out.println(output);
			if(output > 0) {
				System.out.println("Successfully Inserted!!!!");
				lg.info("Data inserted");
			}
			else {
				System.out.println("No matching employees found");
				lg.error("No matching employees found");
			}
			}
			else {
				System.out.println("Invalid resource manager id");
			}
			break;
			
		case 2:
			
			rmgeService=new RmgeServiceImpl();
			List<RequisitionBean> reqList=new ArrayList<RequisitionBean>();
			reqList=rmgeService.getAllRequisition();
			for (RequisitionBean requisitionBean : reqList) {
				System.out.println(requisitionBean);
			}			
			
			break;
			
		case 3:
			rmgeService=new RmgeServiceImpl();
			System.out.println("Enter Resource Manager Id(ex:rm01): ");
			rmid=sc.next();
			/*do {
			
			rmgeService=new RmgeServiceImpl();
			result=rmgeService.validateId(rid);
			}while(result==false);*/
			 //System.out.println("Pending Requisitions: ");
			 List<RequisitionBean> preqList=new ArrayList();
				preqList=rmgeService.getPendingRequisition(rmid);
				for (RequisitionBean prequisitionBean : preqList) 
				{
					System.out.println(prequisitionBean);
				}
				
				
				break;
		case 4:
			rmgeService=new RmgeServiceImpl();
			System.out.println("Enter Resource Manager Id(ex:rm01): ");
			 rmid=sc.next();
			/*do {
			
			 rmgeService=new RmgeServiceImpl();
			result=rmgeService.validateId(rid);
			}while(result==false);
			*/
			
			 List<RequisitionBean> creqList=new ArrayList();
				creqList=rmgeService.getClosedRequisition(rmid);
				if(!(creqList.isEmpty())){
					System.out.println("Closed Requisitions: ");
				for (RequisitionBean crequisitionBean : creqList) {
					System.out.println(crequisitionBean);
				}
				}
				else {
					System.out.println("No closed requisitions found");
				}
				break;
		case 5:
			System.out.println("Successfully Logged Out!!!");
			System.exit(0);
	   default:
				System.out.println("Invalid choice please enter valid choice");
				enterChoiceRmge();
				break;
		}//switch
		
		}//else if
	else {
		System.out.println("Role is not valid");		
		lg.error("enter valid role");
	}//else
}//if
		
		 else {
			 System.out.println("Invalid login credentials!!!");
		 }
 }//main

private static void enterChoiceRmge() {
	do {
		System.out.println("Enter your choice");
		CharSequence choice=sc.next();
		service=new AdminServiceImpl();
		result=service.choiceValidationrmge(choice);
	    c=Integer.parseInt(choice.toString());
	}while(result==false);	
}

private static void enterChoiceRmg() {
	do {
		System.out.println("Enter your choice");
		CharSequence choice1=sc.next();
		rmService=new RmgServiceImpl();
		result=rmService.choiceValidationrmg(choice1);
	    c=Integer.parseInt(choice1.toString());
		}while(result==false);	
}

private static void enterChoice() {
	do {
		System.out.println("Enter Your Choice: ");
		CharSequence choice=sc.next();
		service=new AdminServiceImpl();
		result=service.choiceValidation(choice);
	    c=Integer.parseInt(choice.toString());
		}while(result==false);	
}


private static void deleteById() {
	
	System.out.println("Enter User Id: ");
	user1=sc.next();
}

private static AdminBean checkLoginDetails(AdminBean admin) throws IOException, InternalRecruitmentSystemException {
	ILoginService service = new LoginService();
	return service.checkUserDetails(admin);
}

private static boolean rejectRes(String empId, String reqId1) throws IOException, InternalRecruitmentSystemException {
	rmService=new RmgServiceImpl();
	boolean b=rmService.rejectRes(empId, reqId1);
	return b;
}


}
